Extract GameData folder to your KSP install location. If asked to merge, click yes.
About the .zip included in dowload: Limited-time, see the original mod idea.
Note: Requires Kopernicus. Absolutely WILL NOT work without Kopernicus.